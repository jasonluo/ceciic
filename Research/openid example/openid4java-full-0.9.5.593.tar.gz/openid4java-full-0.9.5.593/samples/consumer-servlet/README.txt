How to run the demo.

Step 1. Install openid4java library.

% cd openid4java
% mvn package install

Step 2. Run the demo.

% cd samples/consumer-servlet
% mvn jetty:run

Step 3. OK.

Open http://localhost:8080/consumer-servlet/ by browser.
