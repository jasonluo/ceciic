package net.wuenschenswert.spring;

/**
 */
public class TestBean {
  String propA;
  String propB;

  public String getPropA() {
    return propA;
  }

  public void setPropA(String propA) {
    this.propA = propA;
  }

  public String getPropB() {
    return propB;
  }

  public void setPropB(String propB) {
    this.propB = propB;
  }
}
